import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  root: "src",
  build: {
    outDir: "../dist-frontend",
    emptyOutDir: true,
  },
  server: {
    proxy: {
      "/ws/terminal": {
        target: "ws://localhost:4000",
        ws: true,
      },
    },
  },
});
